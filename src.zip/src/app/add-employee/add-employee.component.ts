import { Component, OnInit } from '@angular/core';
import { Details, EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  
    user: Details= new Details("",0,0);
    result:string;
 
  constructor(private empSer: EmployeeService) { }

  ngOnInit() {
  }

  AddEmployee():void{
      this.empSer.AddEmployee(this.user)
          .subscribe(data => {
              this.result=data});
      
  }
}
