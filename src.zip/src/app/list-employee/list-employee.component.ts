import { Component, OnInit } from '@angular/core';
import { EmployeeService, Details } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {

  
  service:EmployeeService;
  result: string;
  constructor(service:EmployeeService ,private router:Router) {
    this.service=service;
   }
   emp:Details[]=[]
  ngOnInit(){
    this.service.findAllEmployees();
    this.emp=this.service.getemp();
  }
  delete(e:Details){
    this.service.deleteEmp(e).subscribe(data => {
      this.result=data});;
  }
  update(){
    this.router.navigate(['app-update-employee']);
}
}