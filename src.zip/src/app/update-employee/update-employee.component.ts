import { Component, OnInit } from '@angular/core';
import { EmployeeService, Details } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

 
  user: Details= new Details("",0,0);
    result:string;
 
  constructor(private empSer: EmployeeService) { }

  ngOnInit() {
  }

  updateEmp():void{
      this.empSer.updateEmp(this.user)
          .subscribe(data => {
              this.result=data});
      
  }
}
