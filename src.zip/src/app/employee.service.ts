import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
export class Details{
  empName: string;
  empId: number;
  salary:number;
  constructor(empName: string,
    empId: number,
    salary:number){
      this.empName=empName;
      this.empId=empId;
      this.salary=salary;
    }
}

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }
 emp:Details[]=[];
  public AddEmployee(emp){
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.http.post("http://localhost:2025/employee/AddEmployee",emp,  { headers, responseType: 'text'});
}
public updateEmp(emp){
const headers=new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.http.post("http://localhost:2025/employee/updateEmp",emp,  { headers, responseType: 'text'});

}
public deleteEmp(empId){
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.http.get("http://localhost:2025/employee/deleteEmp/{empId}"+"/"+empId,  { headers, responseType: 'text'});

}
fetched:boolean=false;
public findAllEmployees(){
 
  return this.http.get("http://localhost:2025/employee/findAll").subscribe(
    data=>{if(!this.fetched){
      this.convert(data);
      this.fetched=true;
    }});

}
getemp():Details[]{
  return this.emp;
}
convert(data1:any){
  for(let o of data1){
    let e=new Details(o.empId,o.empName,o.salary);
    this.emp.push(e);
  }
}
}
