package com.employee.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.entity.Details;
import com.employee.exceptions.RecordNotFoundException;
import com.employee.service.EmployeeService;


@RestController
@RequestMapping("/employee")
@CrossOrigin(origins="http://localhost:4200", maxAge=3600)
public class RestControllerApplication 
{
	@Autowired
	EmployeeService empService;
	@PostMapping("/AddEmployee")
	public String createAccount(@RequestBody Details emp) {
		return empService.createEmployee(emp);
	}
	@GetMapping("/findById/{empId}")
	public ResponseEntity<Details> findEmployee(@PathVariable Integer empId) {
		Details employee=empService.findEmployee(empId);
		if(employee == null) {
	         throw new RecordNotFoundException("Invalid employee id : " + empId);
	    }
		ResponseEntity<Details> Response=new ResponseEntity<>(employee,HttpStatus.OK);
		return Response;
	}
	/*@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Id not found")
    @ExceptionHandler(RecordNotFoundException.class)                        //controller level exception handling
    public void RecordNotFoundException() {
    }*/
	@GetMapping("/findAll")
	public List<Details> findAllEmployees() {
		return empService.findAllEmployees();
	}
	@GetMapping(path="/findByName/{empName}")
	public List<Details> findEmployeeByName(@PathVariable String empName) {
		List<Details> employee=empService.findEmpByName(empName);
		if(employee == null) {
	         throw new RecordNotFoundException("Invalid employee Name : " + empName);
	    }
		return employee;
	}
	@PutMapping("/update")
	public String updateEmp(@RequestBody Details emp) {
		return empService.updateEmployee(emp);
	}
	@DeleteMapping("/delete/{empId}")
	public String deleteEmp(@PathVariable Integer empId) {
		return empService.deleteEmpById(empId);
	}
}


