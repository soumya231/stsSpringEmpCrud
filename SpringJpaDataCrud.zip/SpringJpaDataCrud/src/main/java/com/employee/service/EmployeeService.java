package com.employee.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dao.EmployeeDao;
import com.employee.entity.Details;


@Service
public class EmployeeService implements EmployeeServiceI {

	@Autowired
	EmployeeDao empDao;
	@Override
	public String createEmployee(Details emp) {
		empDao.save(emp);
		return "Employee Registered with !!! .." ;
	}

	@Override
	public Details findEmployee(Integer empId) {

		return empDao.findOne(empId);
	}

	@Override
	public List<Details> findAllEmployees() {
	List<Details> emps=	empDao.findAll();
		return emps;
	}

	@Override
	public List<Details> findEmpByName(String empName) {
		return null;

	}

	@Override
	public String updateEmployee(Details emp) {
		boolean result=empDao.exists(emp.getEmpId());
		if(result)
		{
			empDao.save(emp);
			return "Updated Successfully";
		}else
		{
			empDao.save(emp);
			return "Inserted Successfully";
		}
		
	}

	@Override
	public String deleteEmpById(Integer eId) {
		boolean result=empDao.exists(eId);
		if(result)
		{
			empDao.delete(eId);
			return "Deleted Successfully";
		}else
		{
			return "Id Not Found !!!";
		}
	}

}

