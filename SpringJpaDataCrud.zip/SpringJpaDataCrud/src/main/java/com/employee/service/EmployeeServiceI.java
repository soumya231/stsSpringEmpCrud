package com.employee.service;

import java.util.List;
import java.util.Optional;

import com.employee.entity.Details;

public interface EmployeeServiceI {

	String createEmployee(Details emp);

	Optional<Details> findEmployee(Integer empId);

	List<Details> findAllEmployees();

	List<Details> findEmpByName(String empName);

	String updateEmployee(Details emp);

	String deleteEmpById(Integer eId);

}
