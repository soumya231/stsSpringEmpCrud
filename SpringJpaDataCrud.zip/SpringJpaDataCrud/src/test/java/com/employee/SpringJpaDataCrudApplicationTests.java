package com.employee;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaDataCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
